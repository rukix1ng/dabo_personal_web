globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cac5d456dc7f52db.js",
    "static/chunks/e7f0f9d0b78af4b8.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/f78ae9aa7e82892a.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-fbf335fbe0c7fced.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];