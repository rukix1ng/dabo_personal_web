var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__9152a9a7._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_8d6e74ab._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_logout_route_actions_ba173ff4.js")
R.m(50234)
module.exports=R.m(50234).exports
