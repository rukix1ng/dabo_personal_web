var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/papers/route.js")
R.c("server/chunks/[root-of-the-server]__e8659093._.js")
R.c("server/chunks/_8d6e74ab._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3d480eba._.js")
R.c("server/chunks/[root-of-the-server]__497a5f41._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_papers_route_actions_a22a6e85.js")
R.m(53530)
module.exports=R.m(53530).exports
