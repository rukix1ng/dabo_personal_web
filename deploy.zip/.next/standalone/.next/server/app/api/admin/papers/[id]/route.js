var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/papers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b0d3b579._.js")
R.c("server/chunks/_8d6e74ab._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3d480eba._.js")
R.c("server/chunks/[root-of-the-server]__497a5f41._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_papers_[id]_route_actions_9832f12d.js")
R.m(28192)
module.exports=R.m(28192).exports
