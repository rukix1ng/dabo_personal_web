var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__9078b8ea._.js")
R.c("server/chunks/_8d6e74ab._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3d480eba._.js")
R.c("server/chunks/[root-of-the-server]__497a5f41._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_login_route_actions_a223e16c.js")
R.m(48281)
module.exports=R.m(48281).exports
