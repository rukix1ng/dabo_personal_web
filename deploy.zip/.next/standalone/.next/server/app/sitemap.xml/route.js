var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__5e50bd24._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_b6bd895e.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_12658ace.js")
R.m(8922)
module.exports=R.m(8922).exports
