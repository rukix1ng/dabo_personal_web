module.exports=[47289,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_papers_route_actions_a22a6e85.js.map