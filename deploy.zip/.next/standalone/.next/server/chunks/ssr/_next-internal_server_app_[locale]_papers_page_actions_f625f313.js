module.exports=[99096,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_papers_page_actions_f625f313.js.map