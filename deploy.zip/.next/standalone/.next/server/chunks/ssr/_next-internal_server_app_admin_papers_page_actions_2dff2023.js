module.exports=[40399,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_papers_page_actions_2dff2023.js.map