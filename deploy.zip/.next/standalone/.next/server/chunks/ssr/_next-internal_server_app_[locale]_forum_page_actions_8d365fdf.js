module.exports=[34460,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_forum_page_actions_8d365fdf.js.map