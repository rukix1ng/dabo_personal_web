module.exports=[26380,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_achievements_page_actions_0eb34d26.js.map