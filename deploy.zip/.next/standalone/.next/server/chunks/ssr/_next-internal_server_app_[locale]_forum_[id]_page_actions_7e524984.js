module.exports=[21551,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_forum_%5Bid%5D_page_actions_7e524984.js.map